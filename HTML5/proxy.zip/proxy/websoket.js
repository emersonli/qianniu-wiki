var WebSocketServer = require('websocket').server;
var http = require('http');
var proxyPool = {};
var connectPool = {};
var server = http.createServer(function(request, response) {
    if('/console' == request.url){
        response.write('proxy:\r\n');
        for(var k in proxyPool){
            if(!proxyPool.hasOwnProperty(k)){
                return;
            }
            response.write(k +" from "+proxyPool[k].remoteAddress + '\r\n');
        }
        response.write('connect:\r\n');
        for(var k in connectPool){
            if(!connectPool.hasOwnProperty(k)){
                return;
            }
            response.write(k +" from "+connectPool[k].remoteAddress + '\r\n');
        }
    }else{
        console.log((new Date()) + ' Received request for ' + request.url);
        response.writeHead(404);
    }
    response.end();
});
server.listen(30001, function() {
    console.log((new Date()) + ' Server is listening on port 30001');
});

wsServer = new WebSocketServer({
    httpServer: server,
    // You should not use autoAcceptConnections for production
    // applications, as it defeats all standard cross-origin protection
    // facilities built into the protocol and the browser.  You should
    // *always* verify the connection's origin and decide whether or not
    // to accept it.
    autoAcceptConnections: false
});

function requestIsAllowed(request) {
    if (request.requestedProtocols.indexOf('echo-protocol') === -1) {
        return false;
    }
    return true;
}
wsServer.on('request', function(request) {
    
    if (!requestIsAllowed(request)) {
      request.reject();
      return;
    }
    
    var connection = request.accept('echo-protocol', request.origin);
    //判断连接类型
    var pw;
    var to;
    var close;
    if(request.httpRequest && request.httpRequest.url){
        if(request.httpRequest.url.indexOf('/connect/') != -1){
            pw = request.httpRequest.url.substring(9);
            if(!proxyPool[pw]){
                connection.close();
                return;
            }
            if(connectPool[pw]){
                connectPool[pw].close();
            }
            console.log((new Date()) + ' connection ' + pw + ' accept.');
            connectPool[pw] = connection;
            to = proxyPool;
            close = function(){
                delete connectPool[pw];
            }
        }else if(request.httpRequest.url.indexOf('/proxy/') != -1){
            pw = request.httpRequest.url.substring(7);
            if(proxyPool[pw]){
                connection.close();
                return;
            }
            console.log((new Date()) + ' proxy ' + pw + ' accept.');
            proxyPool[pw] = connection;
            to = connectPool;
            close = function(){
                if(connectPool[pw]){
                    connectPool[pw].close();
                }
                delete connectPool[pw];
                delete proxyPool[pw];
            }
        }else{
            connection.close();
            return;
        }
    }
    connection.on('message', function(message) {
        if (message.type === 'utf8') {
            if(to[pw]){
                to[pw].sendUTF(message.utf8Data);
            }
        }
    });
    connection.on('error', function() {
        console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' error happend.');
        close();
    });
    connection.on('close', function(){
        console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' disconnected.');
        close();
    });
});